import os
import re
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib
import pandas as pd
import seaborn as sns
import matplotlib.ticker as plticker
import matplotlib.colors as colors
import glob

# fig = plt.figure(figsize = (7, 5))
fig, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))

theta12s = np.linspace(2.5, 87.5, 18)

theta_values = np.linspace(0, 90.0, 19)
phi_values = np.linspace(0, 180, 19)

# files = ['temp/126/probability_J90_PA.csv', 'temp/96/probability_J90_PA.csv']#, 'probability_LJ93_A05_T11_J90_R10_PA.csv']

files = glob.glob("t05/*")

def sort_temp(val):
    return int(val.split("\\")[1].split("_")[2].split(".")[0][1:])

files.sort(key = sort_temp)

# print(files)

test_full = np.zeros((len(files), 18))

for i, file in enumerate(files):
    df = pd.read_csv(f"{file}")

    test = df.pivot(index='theta1', columns='theta2', values='probability')
    test2 = test.to_numpy()
    # test3 = np.diagonal(test2)
    # test3 = test3 / np.sum(test3)
    test3 = np.sum(test2, axis = 1)

    test_full[i, :] = test3

test_full = 100 * test_full / np.sum(test_full)

out = ax1.pcolormesh(phi_values, theta_values, np.flip(test_full, 0).T, cmap = 'jet', norm=colors.Normalize(vmin=0.0, vmax=0.85), edgecolors='k', linewidths=0.005)
# plt.colorbar(ax=ax2).set_label("probability")

# print(phi_values)
# print(theta_values)
# print(test_full)

ax1.xaxis.set_ticks(np.arange(0, 180.01, 20))
ax1.yaxis.set_ticks(np.arange(0, 90.01, 10))

# ax1.set_title("probability distribution for each $\phi$")

ax1.set_xlabel(r"$\Delta\phi$ (deg)")
ax1.set_ylabel(r"$\theta_i$ or $\theta_j$ (deg)")
# plt.ylabel(r"probability %")

# plt.gca().xaxis.set_ticks(np.arange(0, 90.01, 15))

# plt.grid()

# plt.savefig("plots/probability_vary_TEST.png")

# plt.show()
# plt.close()

# fig = plt.figure(figsize = (7, 5))



# test_full2 = test_full - test_full.mean(axis=0, keepdims=True)

# test_full2 = np.flip(test_full2, 0)


files = glob.glob("t15/*")

files.sort(key = sort_temp)

test_full = np.zeros((len(files), 18))

for i, file in enumerate(files):
    df = pd.read_csv(f"{file}")

    test = df.pivot(index='theta1', columns='theta2', values='probability')
    test2 = test.to_numpy()
    # test3 = np.diagonal(test2)
    # test3 = test3 / np.sum(test3)
    test3 = np.sum(test2, axis = 1)

    test_full[i, :] = test3

test_full = 100 * test_full / np.sum(test_full)

out2 = ax2.pcolormesh(phi_values, theta_values, np.flip(test_full, 0).T, cmap = 'jet', norm=colors.Normalize(vmin=0.0, vmax=0.85), edgecolors='k', linewidths=0.005)
# plt.colorbar(ax=ax2).set_label("probability")

# print(phi_values)
# print(theta_values)
# print(test_full)

# ax2.pcolormesh(phi_values, theta_values, test_full2.T, cmap = 'jet', edgecolors='k', linewidths=0.005)
# plt.colorbar(ax=ax1).set_label("probability difference")

# ax2.set_title("probability differences from mean")

# ax2.set_ylabel(r"$\theta_i, \theta_j$")
ax2.set_xlabel(r"$\Delta\phi$ (deg)")
# plt.ylabel(r"probability %")

ax2.xaxis.set_ticks(np.arange(0, 180.01, 20))
ax2.yaxis.set_ticks(np.arange(0, 90.01, 10))

ax2.set(yticklabels=[])  # remove the tick labels
ax2.tick_params(left=False) 

# plt.axis('square')

# plt.grid()

plt.tight_layout()

fig.subplots_adjust(right=0.875)
cbar_ax = fig.add_axes([0.9, 0.15, 0.02, 0.775])
cbar = fig.colorbar(out, cax=cbar_ax)
cbar.set_label("probability [%]")

ax1.set_aspect(2)
ax2.set_aspect(2)



# plt.savefig("plots/probability_vary_TEST.png")


plt.show()